import os

# Folder containing .txt books
EBOOK_DIR = os.path.join(os.path.dirname(__file__), '..', 'ebooks')
