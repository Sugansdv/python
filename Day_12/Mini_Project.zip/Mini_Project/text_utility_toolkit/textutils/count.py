def count_words(text):
    return len(text.split())

def count_chars(text):
    return len(text)

def count_lines(text):
    return text.count('\n') + 1
