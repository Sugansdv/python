def print_header(title):
    print("=" * len(title))
    print(title)
    print("=" * len(title))
