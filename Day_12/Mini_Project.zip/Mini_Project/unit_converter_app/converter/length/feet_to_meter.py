def convert(feet):
    return feet / 3.28084
