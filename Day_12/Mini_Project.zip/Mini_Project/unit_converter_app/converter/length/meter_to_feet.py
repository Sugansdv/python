def convert(meters):
    return meters * 3.28084
