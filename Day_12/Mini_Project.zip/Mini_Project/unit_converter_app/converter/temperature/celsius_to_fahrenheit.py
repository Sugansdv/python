def c_to_f(celsius):
    return round((celsius * 9/5) + 32, 2)
