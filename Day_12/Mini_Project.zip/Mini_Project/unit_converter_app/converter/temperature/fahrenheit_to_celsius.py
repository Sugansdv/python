def f_to_c(fahrenheit):
    return round((fahrenheit - 32) * 5/9, 2)
