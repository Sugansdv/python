def convert(kg):
    return kg * 2.20462
