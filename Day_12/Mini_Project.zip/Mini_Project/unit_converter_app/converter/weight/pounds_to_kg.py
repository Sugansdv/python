def convert(pounds):
    return pounds / 2.20462
