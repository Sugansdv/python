from weather.cli import start_cli

if __name__ == "__main__":
    start_cli()
